<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Tambah</title>
</head>
<body><br>
<div class="container">
    <h1><center>Tambah</center></h1>
    <form action="proses_tambah.php" method="post"
    enctype="multipart/form-data">
    <div class="form-group">
    <label for="">Foto</label><br>
    <input type="file" name="foto" id="" class="form-control" required><br>

    <label for="">Caption</label><br>
    <input type="text" name="caption" id="" class="form-control" autocomplete="off"><br>

    <label for="">Lokasi</label><br>
    <input type="text" name="lokasi" id="" class="form-control" autocomplete="off"><br>

    <input type="submit" value="simpan" name="simpan">
    </form> 
</div><br>
<a href="index.php"><button>Kembali</button></a>
</body>
</html>