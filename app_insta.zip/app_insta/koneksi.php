<?php
$server = "localhost";
$username = "root";
$password = "123456";
$database = "db_insta";

$koneksi = mysqli_connect($server, $username, $password, $database);

// if ($koneksi){
//     echo "berhasil terkoneksi";
// } else {
//     echo "gagal terkoneksi";
// }
?>