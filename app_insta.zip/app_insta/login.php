<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KFC</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
   
    <link rel="icon" href="images/p.png">
</head>
<body>
    <div class="container">
    <form action="proses_login.php" method="post">
        <div align="center">
            <img src="images/p.png" width="150" height="100" alt="">
        </div><br>

        <label for="username">Username</label>
        <input type="text" id="username" name="username" autocomplete="off" required placeholder=" Enter Username">

        <label for="password">Password</label>
        <input type="password" id="password" name="password" required placeholder="Enter Password">
<br>
        <button input type="submit" value="Sign In" class="btn btn-danger">Log In</button>
    </form>
</div>
</body>
</html>